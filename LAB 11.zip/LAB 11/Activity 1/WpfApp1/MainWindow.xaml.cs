﻿using System.Windows;
using System.Windows.Media.Imaging;

namespace WpfApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            BitmapImage bitmap = new BitmapImage(new Uri("C:\Users\Air Air\source\repos\WpfApp1\WpfApp1\image\pic1.jfif"));
            BitmapImage bitmap = new BitmapImage(new Uri("C:\Users\Air Air\source\repos\WpfApp1\WpfApp1\image 2\pic 2.jfif"));
            myImage.Source = bitmap; // Assuming you have named your Image control as "myImage"
        }
    }
}